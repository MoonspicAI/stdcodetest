# stdcodetest
Standardized Testing Architecture.